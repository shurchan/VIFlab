# google_screener_data_extract
Retrieving of financial metrics of various stocks using python
For more information, pls visit the blog post https://simplypython.wordpress.com/2015/09/26/simple-python-script-to-retrieve-all-stocks-data-from-google-finance-screener/
