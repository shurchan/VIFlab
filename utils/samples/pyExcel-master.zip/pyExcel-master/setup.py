from setuptools import setup

setup(name='pyExcel',
      version='0.1',
      description='Python API to Excel ',
      author='Tan Kok Hua',
      author_email='kokhua81@gmail.com',
      packages=['pyExcel'],
      zip_safe=False)